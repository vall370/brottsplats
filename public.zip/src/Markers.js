import React from "react";
import ReactDOM from "react-dom";
import L from "leaflet";
import carlton from "./fHctp.gif";
import faker from "faker";

import { Map, TileLayer, Marker, Popup } from "react-leaflet";
import MarkerClusterGroup from "react-leaflet-markercluster";
import markers from "./markers";

import "./styles.css";

class Markers extends React.PureComponent {
    render() {
      return (
  
        <MarkerClusterGroup>
          {this.props.markers.map((marker, i) => {
            console.log(marker.position[0]);
            return (
              <Marker
                key={JSON.stringify(marker.position)}
                position={marker.position}
                onClick={this.props.onMarkerClick.bind(null, i)}
              />
            );
          })}
        </MarkerClusterGroup>
      );
    }
  }