import React from 'react';
import styled from 'styled-components';
import MapComp from './Map';

export const Karta = () => (
    <div>
        <MapComp/>
    </div>
    )